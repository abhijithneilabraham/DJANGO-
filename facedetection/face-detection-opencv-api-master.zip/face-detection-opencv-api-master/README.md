# face-detection-opencv-api
An API to detect faces built via. OpenCV deployed using Django 

I have blogged the entire run-through guide at medium where I maintain all of my tech blogs.

Kindly visit - https://medium.com/@rachit.mishra94/building-a-django-post-face-detection-api-using-opencv-and-haar-cascades-a396f7303754

