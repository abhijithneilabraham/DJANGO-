from django.apps import AppConfig


class FaceDetectorConfig(AppConfig):
    name = 'face_detector'
